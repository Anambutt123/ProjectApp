package com.example.blooddonor;

public class User {
}
